# 插件作者:Junius
# 版本:3.1.0 - 新增内置Mixamo默认人物FBX模板绑定

bl_info = {
    "name": "BVH to Mixamo Converter",
    "author": "Junius",
    "version": (3, 1, 0),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > Mixamo Tools",
    "description": "一键将BVH骨骼转化为Mixamo标准骨骼，并可绑定到内置/自定义Mixamo人物FBX模板",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

import bpy
import os
import re
import json
from mathutils import Vector, Matrix
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator, Panel

# -------------------------- Logo预留配置 --------------------------
LOGO_PATH = "icons/logo.png"
LOGO_ICON_ID = None

# -------------------------- 核心:Mixamo标准骨骼映射 --------------------------
DEFAULT_BONE_MAPPING = {
    # 躯干核心骨骼
    "Hips": "mixamorig:Hips",
    "Spine": "mixamorig:Spine",
    "Spine1": "mixamorig:Spine1",
    "Spine2": "mixamorig:Spine2",
    "Neck": "mixamorig:Neck",
    "Head": "mixamorig:Head",

    # 左臂骨骼
    "LeftShoulder": "mixamorig:LeftShoulder",
    "LeftArm": "mixamorig:LeftArm",
    "LeftForeArm": "mixamorig:LeftForeArm",
    "LeftHand": "mixamorig:LeftHand",
    "LeftHandThumb1": "mixamorig:LeftHandThumb1",
    "LeftHandThumb2": "mixamorig:LeftHandThumb2",
    "LeftHandThumb3": "mixamorig:LeftHandThumb3",
    "LeftHandIndex1": "mixamorig:LeftHandIndex1",
    "LeftHandIndex2": "mixamorig:LeftHandIndex2",
    "LeftHandIndex3": "mixamorig:LeftHandIndex3",
    "LeftHandMiddle1": "mixamorig:LeftHandMiddle1",
    "LeftHandMiddle2": "mixamorig:LeftHandMiddle2",
    "LeftHandMiddle3": "mixamorig:LeftHandMiddle3",
    "LeftHandRing1": "mixamorig:LeftHandRing1",
    "LeftHandRing2": "mixamorig:LeftHandRing2",
    "LeftHandRing3": "mixamorig:LeftHandRing3",
    "LeftHandPinky1": "mixamorig:LeftHandPinky1",
    "LeftHandPinky2": "mixamorig:LeftHandPinky2",
    "LeftHandPinky3": "mixamorig:LeftHandPinky3",

    # 右臂骨骼
    "RightShoulder": "mixamorig:RightShoulder",
    "RightArm": "mixamorig:RightArm",
    "RightForeArm": "mixamorig:RightForeArm",
    "RightHand": "mixamorig:RightHand",
    "RightHandThumb1": "mixamorig:RightHandThumb1",
    "RightHandThumb2": "mixamorig:RightHandThumb2",
    "RightHandThumb3": "mixamorig:RightHandThumb3",
    "RightHandIndex1": "mixamorig:RightHandIndex1",
    "RightHandIndex2": "mixamorig:RightHandIndex2",
    "RightHandIndex3": "mixamorig:RightHandIndex3",
    "RightHandMiddle1": "mixamorig:RightHandMiddle1",
    "RightHandMiddle2": "mixamorig:RightHandMiddle2",
    "RightHandMiddle3": "mixamorig:RightHandMiddle3",
    "RightHandRing1": "mixamorig:RightHandRing1",
    "RightHandRing2": "mixamorig:RightHandRing2",
    "RightHandRing3": "mixamorig:RightHandRing3",
    "RightHandPinky1": "mixamorig:RightHandPinky1",
    "RightHandPinky2": "mixamorig:RightHandPinky2",
    "RightHandPinky3": "mixamorig:RightHandPinky3",

    # 左腿骨骼
    "LeftUpLeg": "mixamorig:LeftUpLeg",
    "LeftLeg": "mixamorig:LeftLeg",
    "LeftFoot": "mixamorig:LeftFoot",
    "LeftToeBase": "mixamorig:LeftToeBase",

    # 右腿骨骼
    "RightUpLeg": "mixamorig:RightUpLeg",
    "RightLeg": "mixamorig:RightLeg",
    "RightFoot": "mixamorig:RightFoot",
    "RightToeBase": "mixamorig:RightToeBase",
}


# -------------------------- v3.0:JSON骨骼映射配置 --------------------------
MAPPING_PRESET_DEFAULT = 'DEFAULT_JSON'
MAPPING_PRESET_CUSTOM = 'CUSTOM_JSON'
DEFAULT_MAPPING_JSON_FILENAME = 'default_mixamo_mapping.json'


# -------------------------- v3.1:FBX人物模板配置 --------------------------
TEMPLATE_PRESET_BUILTIN_DEFAULT = 'BUILTIN_DEFAULT_CHARACTER'
TEMPLATE_PRESET_CUSTOM_FBX = 'CUSTOM_FBX'
DEFAULT_TEMPLATE_FBX_FILENAME = 'mixamo_default_character.fbx'

# 未来添加更多一键绑定模板时，只需要：
# 1. 把FBX放入 templates/ 目录
# 2. 在 TEMPLATE_REGISTRY 中新增一条记录
# 3. 如需显示到UI，再在 EnumProperty items 中新增对应项
TEMPLATE_REGISTRY = {
    TEMPLATE_PRESET_BUILTIN_DEFAULT: {
        "name": "Mixamo默认人物模型",
        "filename": DEFAULT_TEMPLATE_FBX_FILENAME,
        "description": "插件内置的Mixamo标准人物FBX模板"
    }
}

def get_templates_dir():
    """获取内置FBX人物模板目录"""
    return os.path.join(get_addon_dir(), "templates")

def get_default_template_fbx_path():
    """获取内置默认Mixamo人物FBX路径"""
    return os.path.join(get_templates_dir(), DEFAULT_TEMPLATE_FBX_FILENAME)

def get_template_fbx_path(context):
    """根据UI设置获取当前人物FBX模板路径"""
    preset = getattr(context.scene, "bvh_template_preset", TEMPLATE_PRESET_BUILTIN_DEFAULT)

    if preset == TEMPLATE_PRESET_CUSTOM_FBX:
        custom_path = getattr(context.scene, "bvh_custom_template_fbx_path", "")
        if not custom_path:
            raise FileNotFoundError("请选择自定义Mixamo人物FBX文件")
        if not os.path.exists(custom_path):
            raise FileNotFoundError(f"自定义人物FBX不存在: {custom_path}")
        if not custom_path.lower().endswith(".fbx"):
            raise ValueError("自定义人物模板必须是.fbx文件")
        return custom_path

    info = TEMPLATE_REGISTRY.get(preset, TEMPLATE_REGISTRY[TEMPLATE_PRESET_BUILTIN_DEFAULT])
    filepath = os.path.join(get_templates_dir(), info["filename"])
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"内置人物FBX模板不存在: {filepath}")
    return filepath

def find_mixamo_armature_in_objects(objects):
    """从一组对象中寻找Mixamo格式骨架，优先返回标准Mixamo骨架"""
    armatures = [obj for obj in objects if obj and obj.type == 'ARMATURE']
    for armature in armatures:
        if is_mixamo_armature(armature):
            return armature
    return armatures[0] if armatures else None

def import_character_template_fbx(fbx_path):
    """导入人物FBX模板，返回目标骨架和本次导入对象列表"""
    if not fbx_path or not os.path.exists(fbx_path):
        raise FileNotFoundError(f"人物FBX模板不存在: {fbx_path}")

    before_objects = set(bpy.data.objects)
    print(f"📦 开始导入人物FBX模板: {fbx_path}")
    bpy.ops.import_scene.fbx(filepath=fbx_path)
    imported_objects = [obj for obj in bpy.data.objects if obj not in before_objects]

    if not imported_objects:
        raise RuntimeError("FBX导入后未检测到新增对象")

    target_armature = find_mixamo_armature_in_objects(imported_objects)
    if not target_armature:
        # 兼容某些导入器选择集返回，但bpy.data对象差集为空的情况
        target_armature = find_mixamo_armature_in_objects(bpy.context.selected_objects)

    if not target_armature:
        raise RuntimeError("FBX模板中未找到Armature骨架对象")

    if not is_mixamo_armature(target_armature):
        print("⚠️ 模板FBX骨架不是典型Mixamo命名，但仍尝试作为目标骨架使用")

    # 清理模板自带动画，避免和新BVH动画混杂
    if target_armature.animation_data and target_armature.animation_data.action:
        target_armature.animation_data.action = None

    # 统一命名，方便场景管理
    base_name = os.path.splitext(os.path.basename(fbx_path))[0]
    target_armature.name = f"{base_name}_AnimatedRig"
    target_armature.data.name = f"{base_name}_AnimatedRigData"

    for obj in imported_objects:
        obj.select_set(False)
    target_armature.select_set(True)
    bpy.context.view_layer.objects.active = target_armature

    print(f"✅ 人物FBX模板导入完成，目标骨架: {target_armature.name}，导入对象数: {len(imported_objects)}")
    return target_armature, imported_objects


def get_addon_dir():
    """获取插件目录"""
    return os.path.dirname(os.path.abspath(__file__))


def get_presets_dir():
    """获取内置映射预设目录"""
    return os.path.join(get_addon_dir(), "presets")


def get_default_mapping_json_path():
    """获取内置默认JSON映射路径"""
    return os.path.join(get_presets_dir(), DEFAULT_MAPPING_JSON_FILENAME)


def get_default_mapping():
    """返回代码内置默认映射副本，作为JSON读取失败时的fallback"""
    return DEFAULT_BONE_MAPPING.copy()


def validate_mapping_dict(mapping):
    """清洗并校验mapping字典"""
    if not isinstance(mapping, dict):
        raise ValueError("mapping字段必须是JSON对象/dict")

    cleaned_mapping = {}
    for source_name, target_name in mapping.items():
        if not isinstance(source_name, str) or not isinstance(target_name, str):
            continue
        source_name = source_name.strip()
        target_name = target_name.strip()
        if source_name and target_name:
            cleaned_mapping[source_name] = target_name

    if not cleaned_mapping:
        raise ValueError("mapping字段为空，未找到有效骨骼映射")

    return cleaned_mapping


def load_mapping_json(filepath):
    """
    从JSON文件加载骨骼映射。
    推荐格式:
    {
        "name": "Default Mixamo Mapping",
        "description": "...",
        "version": "1.0",
        "target": "mixamo",
        "mapping": {
            "Hips": "mixamorig:Hips"
        }
    }
    兼容简单格式:
    {
        "Hips": "mixamorig:Hips"
    }
    """
    if not filepath:
        raise FileNotFoundError("未提供JSON映射文件路径")
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"JSON映射文件不存在: {filepath}")

    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict) and "mapping" in data:
        mapping = data["mapping"]
    else:
        mapping = data

    return validate_mapping_dict(mapping)


def load_builtin_default_mapping():
    """优先从内置JSON读取默认映射；失败则回退到代码内置DEFAULT_BONE_MAPPING"""
    json_path = get_default_mapping_json_path()
    try:
        mapping = load_mapping_json(json_path)
        print(f"✅ 已加载内置JSON骨骼映射: {json_path}")
        return mapping
    except Exception as e:
        print(f"⚠️ 内置JSON映射加载失败，使用代码内置默认映射: {e}")
        return get_default_mapping()


def get_active_bone_mapping(context):
    """根据UI设置获取当前激活的骨骼映射"""
    preset = getattr(context.scene, "bvh_mapping_preset", MAPPING_PRESET_DEFAULT)

    if preset == MAPPING_PRESET_CUSTOM:
        custom_path = getattr(context.scene, "bvh_custom_mapping_path", "")
        mapping = load_mapping_json(custom_path)
        print(f"✅ 已加载自定义JSON骨骼映射: {custom_path}")
        return mapping

    return load_builtin_default_mapping()


def diagnose_mapping(armature, bone_mapping):
    """诊断当前BVH骨架与映射表的匹配情况"""
    if not armature or armature.type != 'ARMATURE':
        return None

    source_bones = set(bone.name for bone in armature.data.bones)
    mapping_sources = set(bone_mapping.keys())
    matched = source_bones.intersection(mapping_sources)
    missing = mapping_sources - source_bones
    extra = source_bones - mapping_sources

    report = {
        "source_bone_count": len(source_bones),
        "mapping_count": len(mapping_sources),
        "matched_count": len(matched),
        "missing_count": len(missing),
        "extra_count": len(extra),
        "matched": sorted(matched),
        "missing": sorted(missing),
        "extra": sorted(extra),
    }

    print("===== 骨骼映射诊断 =====")
    print(f"源骨骼数量: {report['source_bone_count']}")
    print(f"映射表骨骼数量: {report['mapping_count']}")
    print(f"成功匹配: {report['matched_count']}")
    print(f"映射表中存在但BVH缺失: {report['missing_count']}")
    print(f"BVH中存在但映射表未配置: {report['extra_count']}")
    if report["missing"]:
        print("缺失骨骼(前20个):")
        for bone_name in report["missing"][:20]:
            print(f"  - {bone_name}")
    if report["extra"]:
        print("未配置骨骼(前20个):")
        for bone_name in report["extra"][:20]:
            print(f"  - {bone_name}")

    return report

# -------------------------- Mixamo标准骨骼层级 --------------------------
MIXAMO_BONE_HIERARCHY = {
    "mixamorig:Hips": ["mixamorig:Spine", "mixamorig:LeftUpLeg", "mixamorig:RightUpLeg"],
    "mixamorig:Spine": ["mixamorig:Spine1"],
    "mixamorig:Spine1": ["mixamorig:Spine2"],
    "mixamorig:Spine2": ["mixamorig:Neck", "mixamorig:LeftShoulder", "mixamorig:RightShoulder"],
    "mixamorig:Neck": ["mixamorig:Head"],

    # 左臂层级
    "mixamorig:LeftShoulder": ["mixamorig:LeftArm"],
    "mixamorig:LeftArm": ["mixamorig:LeftForeArm"],
    "mixamorig:LeftForeArm": ["mixamorig:LeftHand"],
    "mixamorig:LeftHand": [
        "mixamorig:LeftHandThumb1", "mixamorig:LeftHandIndex1", 
        "mixamorig:LeftHandMiddle1", "mixamorig:LeftHandRing1", "mixamorig:LeftHandPinky1"
    ],
    "mixamorig:LeftHandThumb1": ["mixamorig:LeftHandThumb2"],
    "mixamorig:LeftHandThumb2": ["mixamorig:LeftHandThumb3"],
    "mixamorig:LeftHandIndex1": ["mixamorig:LeftHandIndex2"],
    "mixamorig:LeftHandIndex2": ["mixamorig:LeftHandIndex3"],
    "mixamorig:LeftHandMiddle1": ["mixamorig:LeftHandMiddle2"],
    "mixamorig:LeftHandMiddle2": ["mixamorig:LeftHandMiddle3"],
    "mixamorig:LeftHandRing1": ["mixamorig:LeftHandRing2"],
    "mixamorig:LeftHandRing2": ["mixamorig:LeftHandRing3"],
    "mixamorig:LeftHandPinky1": ["mixamorig:LeftHandPinky2"],
    "mixamorig:LeftHandPinky2": ["mixamorig:LeftHandPinky3"],

    # 右臂层级
    "mixamorig:RightShoulder": ["mixamorig:RightArm"],
    "mixamorig:RightArm": ["mixamorig:RightForeArm"],
    "mixamorig:RightForeArm": ["mixamorig:RightHand"],
    "mixamorig:RightHand": [
        "mixamorig:RightHandThumb1", "mixamorig:RightHandIndex1", 
        "mixamorig:RightHandMiddle1", "mixamorig:RightHandRing1", "mixamorig:RightHandPinky1"
    ],
    "mixamorig:RightHandThumb1": ["mixamorig:RightHandThumb2"],
    "mixamorig:RightHandThumb2": ["mixamorig:RightHandThumb3"],
    "mixamorig:RightHandIndex1": ["mixamorig:RightHandIndex2"],
    "mixamorig:RightHandIndex2": ["mixamorig:RightHandIndex3"],
    "mixamorig:RightHandMiddle1": ["mixamorig:RightHandMiddle2"],
    "mixamorig:RightHandMiddle2": ["mixamorig:RightHandMiddle3"],
    "mixamorig:RightHandRing1": ["mixamorig:RightHandRing2"],
    "mixamorig:RightHandRing2": ["mixamorig:RightHandRing3"],
    "mixamorig:RightHandPinky1": ["mixamorig:RightHandPinky2"],
    "mixamorig:RightHandPinky2": ["mixamorig:RightHandPinky3"],

    # 左腿层级
    "mixamorig:LeftUpLeg": ["mixamorig:LeftLeg"],
    "mixamorig:LeftLeg": ["mixamorig:LeftFoot"],
    "mixamorig:LeftFoot": ["mixamorig:LeftToeBase"],

    # 右腿层级
    "mixamorig:RightUpLeg": ["mixamorig:RightLeg"],
    "mixamorig:RightLeg": ["mixamorig:RightFoot"],
    "mixamorig:RightFoot": ["mixamorig:RightToeBase"],
}

# -------------------------- Logo加载工具 --------------------------
def load_logo():
    global LOGO_ICON_ID
    if LOGO_ICON_ID is not None:
        return LOGO_ICON_ID
    addon_path = os.path.dirname(os.path.abspath(__file__))
    logo_abs_path = os.path.join(addon_path, LOGO_PATH)
    if os.path.exists(logo_abs_path):
        try:
            preview_collection = bpy.utils.previews.new()
            preview_collection.load('plugin_logo', logo_abs_path, 'IMAGE')
            LOGO_ICON_ID = preview_collection
            print(f"✅ 加载Logo成功:{logo_abs_path}")
        except Exception as e:
            print(f"⚠️ Logo加载失败:{str(e)}")
            LOGO_ICON_ID = None
    else:
        print(f"⚠️ Logo文件不存在:{logo_abs_path}(使用默认图标)")
        LOGO_ICON_ID = None
    return LOGO_ICON_ID

def unload_logo():
    global LOGO_ICON_ID
    if LOGO_ICON_ID is not None:
        bpy.utils.previews.remove(LOGO_ICON_ID)
        LOGO_ICON_ID = None
    print("✅ Logo资源已卸载")

# -------------------------- 新增:读取BVH帧率 --------------------------
def read_bvh_framerate(bvh_path):
    """从BVH文件读取帧率"""
    try:
        with open(bvh_path, 'r') as f:
            for line in f:
                if 'Frame Time:' in line:
                    match = re.search(r'Frame Time:\s*([\d.]+)', line)
                    if match:
                        frame_time = float(match.group(1))
                        fps = 1.0 / frame_time
                        print(f"📊 检测到BVH帧率: {fps:.2f} FPS (帧时间: {frame_time}s)")
                        return fps
    except Exception as e:
        print(f"⚠️ 读取BVH帧率失败: {e}")
    
    print("⚠️ 未检测到BVH帧率,使用默认值: 30 FPS")
    return 30.0

# -------------------------- 新增:检测Mixamo骨骼 --------------------------
def is_mixamo_armature(armature):
    """检测是否为Mixamo格式骨骼"""
    if not armature or armature.type != 'ARMATURE':
        return False
    
    # 检查是否包含关键Mixamo骨骼
    key_bones = ["mixamorig:Hips", "mixamorig:Spine", "mixamorig:LeftArm", "mixamorig:RightArm"]
    found_count = sum(1 for bone_name in key_bones if bone_name in armature.data.bones)
    
    return found_count >= 3  # 至少包含3个关键骨骼

def get_selected_mixamo_armature():
    """获取选中的Mixamo格式骨骼"""
    selected = bpy.context.selected_objects
    for obj in selected:
        if is_mixamo_armature(obj):
            return obj
    return None

# -------------------------- 新增:计算骨骼比例 --------------------------
def calculate_armature_scale_ratio(source_armature, target_armature):
    """计算源骨骼和目标骨骼的比例差异"""
    # 使用Hips骨骼作为参考点计算比例
    reference_bone_name = "mixamorig:Hips"
    
    if reference_bone_name not in source_armature.data.bones or \
       reference_bone_name not in target_armature.data.bones:
        print("⚠️ 未找到参考骨骼,使用默认比例 1.0")
        return 1.0
    
    # 获取两个骨骼的Hips长度
    source_hips = source_armature.data.bones[reference_bone_name]
    target_hips = target_armature.data.bones[reference_bone_name]
    
    # 计算骨骼长度(头到尾的距离)
    source_length = source_hips.length
    target_length = target_hips.length
    
    if source_length == 0:
        print("⚠️ 源骨骼长度为0,使用默认比例 1.0")
        return 1.0
    
    ratio = target_length / source_length
    print(f"📏 骨骼比例计算:")
    print(f"  源Hips长度: {source_length:.4f}")
    print(f"  目标Hips长度: {target_length:.4f}")
    print(f"  比例: {ratio:.4f}")
    
    return ratio

# -------------------------- 新增:动画数据转移 --------------------------
def transfer_animation(source_armature, target_armature):
    """将源骨骼的动画数据转移到目标骨骼 - 使用NLA约束重定向"""
    print(f"🔄 开始转移动画...")
    print(f"  源骨骼: {source_armature.name}")
    print(f"  目标骨骼: {target_armature.name}")
    
    if not source_armature.animation_data:
        print("❌ 源骨骼没有animation_data!")
        return False
        
    if not source_armature.animation_data.action:
        print("❌ 源骨骼没有action!")
        return False
    
    source_action = source_armature.animation_data.action
    print(f"✅ 源动画: {source_action.name}, F曲线数: {len(source_action.fcurves)}")
    
    # 1. 确保源骨骼和目标骨骼都存在
    if not source_armature or not target_armature:
        print("❌ 源或目标骨骼不存在!")
        return False
    
    # 2. 计算并应用比例调整
    scale_ratio = calculate_armature_scale_ratio(source_armature, target_armature)
    
    # 保存源骨骼的原始缩放
    original_scale = source_armature.scale.copy()
    
    # 将源骨骼缩放到目标骨骼的尺寸
    source_armature.scale = (scale_ratio, scale_ratio, scale_ratio)
    bpy.context.view_layer.update()
    print(f"✅ 已将源骨骼缩放至目标尺寸 (比例: {scale_ratio:.4f})")
    
    # 3. 保存当前场景状态
    original_frame = bpy.context.scene.frame_current
    original_active = bpy.context.view_layer.objects.active
    
    # 4. 获取动画帧范围
    frame_start = int(source_action.frame_range[0])
    frame_end = int(source_action.frame_range[1])
    print(f"📊 动画帧范围: {frame_start} - {frame_end}")
    
    # 5. 为目标骨骼创建约束并烘焙动画
    try:
        # 设置源骨骼为当前活动对象
        bpy.context.view_layer.objects.active = source_armature
        source_armature.select_set(True)
        
        # 确保目标骨骼有动画数据
        if not target_armature.animation_data:
            target_armature.animation_data_create()
        
        # 清空目标骨骼现有动画
        if target_armature.animation_data.action:
            target_armature.animation_data.action = None
        
        # 为目标骨骼的每个姿态骨骼添加复制变换约束
        bpy.context.view_layer.objects.active = target_armature
        bpy.ops.object.mode_set(mode='POSE')
        
        constraints_added = 0
        
        # 首先需要对齐两个骨骼的根位置
        # 将源骨骼移动到目标骨骼的位置
        target_root_pos = target_armature.location.copy()
        source_original_pos = source_armature.location.copy()
        source_armature.location = target_root_pos
        bpy.context.view_layer.update()
        print(f"✅ 已对齐源骨骼到目标位置")
        
        for pose_bone in target_armature.pose.bones:
            bone_name = pose_bone.name
            
            # 检查源骨骼是否有对应骨骼
            if bone_name in source_armature.pose.bones:
                # 清除现有约束
                for constraint in pose_bone.constraints:
                    pose_bone.constraints.remove(constraint)
                
                # 根骨骼(Hips)需要复制位置和旋转
                if bone_name == "mixamorig:Hips":
                    # 复制位置 - 使用局部空间
                    loc_constraint = pose_bone.constraints.new('COPY_LOCATION')
                    loc_constraint.target = source_armature
                    loc_constraint.subtarget = bone_name
                    loc_constraint.target_space = 'LOCAL'
                    loc_constraint.owner_space = 'LOCAL'
                    loc_constraint.use_x = True
                    loc_constraint.use_y = True
                    loc_constraint.use_z = True
                
                # 所有骨骼复制旋转
                # 对于四肢使用POSE空间(世界旋转),对于躯干使用LOCAL空间
                # 判断是否为四肢骨骼
                limb_bones = [
                    "LeftArm", "LeftForeArm", "LeftHand",
                    "RightArm", "RightForeArm", "RightHand",
                    "LeftUpLeg", "LeftLeg", "LeftFoot",
                    "RightUpLeg", "RightLeg", "RightFoot"
                ]
                
                is_limb = any(limb in bone_name for limb in limb_bones)
                
                rot_constraint = pose_bone.constraints.new('COPY_ROTATION')
                rot_constraint.target = source_armature
                rot_constraint.subtarget = bone_name
                
                if is_limb:
                    # 四肢使用POSE空间(考虑父骨骼影响)
                    rot_constraint.target_space = 'POSE'
                    rot_constraint.owner_space = 'POSE'
                else:
                    # 躯干、头部使用LOCAL空间
                    rot_constraint.target_space = 'LOCAL'
                    rot_constraint.owner_space = 'LOCAL'
                
                constraints_added += 1
        
        print(f"✅ 添加了 {constraints_added} 个骨骼约束")
        
        # 6. 烘焙动画
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.view_layer.objects.active = target_armature
        target_armature.select_set(True)
        source_armature.select_set(False)
        
        bpy.ops.object.mode_set(mode='POSE')
        
        # 选择所有姿态骨骼
        for pose_bone in target_armature.pose.bones:
            pose_bone.bone.select = True
        
        print(f"🔥 开始烘焙动画 ({frame_start} - {frame_end})...")
        
        # 烘焙动画到目标骨骼
        bpy.ops.nla.bake(
            frame_start=frame_start,
            frame_end=frame_end,
            only_selected=True,
            visual_keying=True,
            clear_constraints=True,
            clear_parents=False,
            use_current_action=False,
            bake_types={'POSE'}
        )
        
        print(f"✅ 动画烘焙完成!")
        
        # 7. 清理约束(如果烘焙时没有自动清理)
        bpy.ops.object.mode_set(mode='POSE')
        for pose_bone in target_armature.pose.bones:
            for constraint in list(pose_bone.constraints):
                pose_bone.constraints.remove(constraint)
        
        # 8. 切换回物体模式
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # 9. 恢复源骨骼的原始缩放和位置
        source_armature.scale = original_scale
        source_armature.location = source_original_pos
        bpy.context.view_layer.update()
        print(f"✅ 已恢复源骨骼原始变换")
        
        # 10. 验证动画
        if target_armature.animation_data and target_armature.animation_data.action:
            action = target_armature.animation_data.action
            print(f"✅ 目标骨骼动画:")
            print(f"  - 名称: {action.name}")
            print(f"  - F曲线数: {len(action.fcurves)}")
            print(f"  - 帧范围: {action.frame_range}")
            return True
        else:
            print(f"❌ 烘焙后未找到动画数据!")
            return False
        
    except Exception as e:
        import traceback
        print(f"❌ 动画转移失败: {str(e)}")
        print(traceback.format_exc())
        # 恢复源骨骼变换
        source_armature.scale = original_scale
        source_armature.location = source_original_pos
        bpy.context.view_layer.update()
        return False
    
    finally:
        # 恢复场景状态
        bpy.context.scene.frame_current = original_frame
        if original_active:
            bpy.context.view_layer.objects.active = original_active
        bpy.ops.object.mode_set(mode='OBJECT')

# -------------------------- 核心功能函数 --------------------------
def import_bvh(bvh_path, match_fps=True):
    """导入BVH文件并设置正确的帧率"""
    if not os.path.exists(bvh_path) or not bvh_path.lower().endswith(".bvh"):
        return None, None
    
    # 读取BVH原始帧率
    bvh_fps = read_bvh_framerate(bvh_path)
    
    # 如果启用帧率匹配,设置场景帧率
    if match_fps:
        bpy.context.scene.render.fps = int(round(bvh_fps))
        bpy.context.scene.render.fps_base = 1.0
        print(f"✅ 场景帧率已设置为: {bpy.context.scene.render.fps} FPS")
    
    # 导入BVH
    bpy.ops.import_anim.bvh(
        filepath=bvh_path,
        axis_forward='-Z',
        axis_up='Y',
        target='ARMATURE',
        use_fps_scale=False,
        update_scene_fps=match_fps,
        update_scene_duration=True,
        use_cyclic=False,
        rotate_mode='NATIVE'
    )
    
    armature = bpy.context.selected_objects[0] if bpy.context.selected_objects else None
    return armature, bvh_fps

def process_bones(armature, bone_mapping=None, update_animation=True):
    """处理骨骼:映射名称+修复层级+修正位置"""
    if bone_mapping is None:
        bone_mapping = get_default_mapping()
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='EDIT')
    
    edit_bones = armature.data.edit_bones
    
    # 1. 先保存原始骨骼位置信息
    bone_positions = {}
    for old_name in bone_mapping.keys():
        if old_name in edit_bones:
            bone = edit_bones[old_name]
            bone_positions[old_name] = {
                'head': bone.head.copy(),
                'tail': bone.tail.copy(),
                'roll': bone.roll,
                'matrix': bone.matrix.copy()
            }
    
    # 2. 清理多余骨骼
    bvh_bone_names = set(bone.name for bone in edit_bones)
    keep_bvh_names = set(bone_mapping.keys())
    bones_to_delete = [name for name in bvh_bone_names if name not in keep_bvh_names]
    
    extra_end_bones = ["HeadTop_End", "LeftToeEnd", "RightToeEnd"]
    for end_bone in extra_end_bones:
        if end_bone in edit_bones and end_bone not in bones_to_delete:
            bones_to_delete.append(end_bone)
    
    for bone_name in bones_to_delete:
        if bone_name in edit_bones:
            edit_bones.remove(edit_bones[bone_name])
    print(f"✅ 清理多余骨骼:共删除 {len(bones_to_delete)} 个")
    
    # 3. 切换到物体模式以更新动画数据路径
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 4. 更新动画数据中的骨骼名称引用
    if update_animation and armature.animation_data and armature.animation_data.action:
        action = armature.animation_data.action
        print(f"📝 更新动画数据中的骨骼引用...")
        
        # 收集需要更新的F曲线
        fcurves_to_update = []
        for fcurve in action.fcurves:
            if 'pose.bones[' in fcurve.data_path:
                match = re.search(r'pose\.bones\["([^"]+)"\]', fcurve.data_path)
                if match:
                    old_bone_name = match.group(1)
                    if old_bone_name in bone_mapping:
                        new_bone_name = bone_mapping[old_bone_name]
                        fcurves_to_update.append((fcurve, old_bone_name, new_bone_name))
        
        # 更新F曲线的数据路径
        for fcurve, old_name, new_name in fcurves_to_update:
            old_path = fcurve.data_path
            new_path = old_path.replace(f'pose.bones["{old_name}"]', f'pose.bones["{new_name}"]')
            fcurve.data_path = new_path
        
        print(f"✅ 更新了 {len(fcurves_to_update)} 条F曲线的骨骼引用")
    
    # 5. 重新进入编辑模式继续处理
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = armature.data.edit_bones
    
    # 6. 映射骨骼名称
    mapped_count = 0
    for old_name, new_name in bone_mapping.items():
        if old_name in edit_bones:
            edit_bones[old_name].name = new_name
            mapped_count += 1
    print(f"✅ 骨骼名称映射:成功映射 {mapped_count} 个核心骨骼")
    
    # 7. 修复骨骼层级
    for parent_name, child_names in MIXAMO_BONE_HIERARCHY.items():
        if parent_name in edit_bones:
            parent_bone = edit_bones[parent_name]
            for child_name in child_names:
                if child_name in edit_bones:
                    child_bone = edit_bones[child_name]
                    original_head = child_bone.head.copy()
                    original_tail = child_bone.tail.copy()
                    original_roll = child_bone.roll
                    
                    child_bone.parent = parent_bone
                    
                    child_bone.head = original_head
                    child_bone.tail = original_tail
                    child_bone.roll = original_roll
                    
                    if child_bone.length < 0.001:
                        direction = (child_bone.tail - child_bone.head).normalized()
                        child_bone.tail = child_bone.head + direction * 0.01
    
    print(f"✅ 骨骼层级修复完成(保持原始位置)")
    
    # 8. 特别处理腿部分叉
    if "mixamorig:Hips" in edit_bones:
        hips = edit_bones["mixamorig:Hips"]
        
        if "mixamorig:LeftUpLeg" in edit_bones:
            left_leg = edit_bones["mixamorig:LeftUpLeg"]
            left_leg.parent = hips
            left_leg.use_connect = False
        
        if "mixamorig:RightUpLeg" in edit_bones:
            right_leg = edit_bones["mixamorig:RightUpLeg"]
            right_leg.parent = hips
            right_leg.use_connect = False
    
    # 9. 确保所有子骨骼不使用连接
    for bone in edit_bones:
        if bone.parent:
            bone.use_connect = False
    
    print(f"✅ 骨骼位置优化完成")
    
    # 10. 切换到物体模式
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = armature
    armature.select_set(True)
    
    return armature

def verify_animation_data(armature):
    """验证动画数据是否正确"""
    if not armature.animation_data or not armature.animation_data.action:
        print("⚠️ 警告:骨架没有动画数据!")
        return False
    
    action = armature.animation_data.action
    fcurves = action.fcurves
    
    if len(fcurves) == 0:
        print("⚠️ 警告:动画没有关键帧曲线!")
        return False
    
    total_keyframes = sum(len(fc.keyframe_points) for fc in fcurves)
    frame_range = action.frame_range
    
    print(f"✅ 动画数据验证:")
    print(f"  - 动画名称: {action.name}")
    print(f"  - 曲线数量: {len(fcurves)}")
    print(f"  - 总关键帧: {total_keyframes}")
    print(f"  - 帧范围: {frame_range[0]:.0f} - {frame_range[1]:.0f}")
    
    return True

# -------------------------- 操作类 --------------------------
class MIXAMO_OT_convert(Operator):
    bl_idname = "mixamo.convert_bvh"
    bl_label = "生成/绑定动画"
    bl_description = "将BVH转换为Mixamo骨骼或绑定到现有骨骼"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bvh_path = context.scene.bvh_input_path
        match_fps = context.scene.bvh_match_fps
        bind_mode = context.scene.bvh_bind_mode
        
        if not bvh_path:
            self.report({'ERROR'}, "请选择BVH输入文件!")
            return {'CANCELLED'}
        
        if not bvh_path.lower().endswith(".bvh"):
            self.report({'ERROR'}, "请选择有效的BVH文件(.bvh后缀)!")
            return {'CANCELLED'}
        
        try:
            print("===== 开始BVH→Mixamo转化 =====")
            
            # 检查绑定模式
            target_armature = None
            selected_target_armature = None
            imported_template_objects = []

            if bind_mode in {'BIND', 'BIND_SELECTED'}:
                selected_target_armature = get_selected_mixamo_armature()
                if not selected_target_armature:
                    self.report({'ERROR'}, "绑定到选中骨骼模式:请先选中一个Mixamo格式的骨骼!")
                    return {'CANCELLED'}
                print(f"🎯 绑定到选中骨骼:目标骨骼 = {selected_target_armature.name}")

            # 加载当前骨骼映射配置
            try:
                bone_mapping = get_active_bone_mapping(context)
            except Exception as e:
                self.report({'ERROR'}, f"骨骼映射JSON加载失败: {str(e)}")
                return {'CANCELLED'}
            
            # 导入BVH
            source_armature, bvh_fps = import_bvh(bvh_path, match_fps)
            if not source_armature:
                self.report({'ERROR'}, "BVH导入失败!请检查文件路径和格式。")
                return {'CANCELLED'}
            
            # 诊断映射匹配情况
            diagnosis = diagnose_mapping(source_armature, bone_mapping)
            if diagnosis and diagnosis['matched_count'] == 0:
                self.report({'ERROR'}, "当前JSON映射与BVH骨骼完全不匹配，请检查预设或自定义JSON。")
                return {'CANCELLED'}
            
            # 处理骨骼映射
            processed_armature = process_bones(source_armature, bone_mapping=bone_mapping, update_animation=True)
            
            # 验证动画数据
            if not verify_animation_data(processed_armature):
                self.report({'WARNING'}, "动画数据可能不完整,请检查!")
            
            print(f"📊 处理后的动画数据:")
            if processed_armature.animation_data and processed_armature.animation_data.action:
                action = processed_armature.animation_data.action
                print(f"  - 动作名称: {action.name}")
                print(f"  - F曲线数量: {len(action.fcurves)}")
                # 打印前5条F曲线的路径
                for i, fc in enumerate(action.fcurves[:5]):
                    print(f"  - F曲线 {i}: {fc.data_path}")
            
            # 根据模式处理
            if bind_mode in {'BIND', 'BIND_SELECTED'}:
                target_armature = selected_target_armature
                if transfer_animation(processed_armature, target_armature):
                    bpy.data.objects.remove(processed_armature, do_unlink=True)
                    bpy.context.view_layer.objects.active = target_armature
                    target_armature.select_set(True)
                    msg = f"✅ 成功绑定动画到选中骨架 {target_armature.name}! (FPS: {bpy.context.scene.render.fps})"
                    self.report({'INFO'}, msg)
                    print(f"===== 绑定完成:{msg} =====")
                else:
                    self.report({'ERROR'}, "动画转移失败!")
                    return {'CANCELLED'}

            elif bind_mode == 'BIND_TEMPLATE':
                try:
                    template_fbx_path = get_template_fbx_path(context)
                    target_armature, imported_template_objects = import_character_template_fbx(template_fbx_path)
                except Exception as e:
                    self.report({'ERROR'}, f"人物FBX模板导入失败: {str(e)}")
                    return {'CANCELLED'}

                if transfer_animation(processed_armature, target_armature):
                    bpy.data.objects.remove(processed_armature, do_unlink=True)
                    for obj in bpy.context.scene.objects:
                        obj.select_set(False)
                    for obj in imported_template_objects:
                        if obj and obj.name in bpy.data.objects:
                            obj.select_set(True)
                    bpy.context.view_layer.objects.active = target_armature
                    target_armature.select_set(True)
                    msg = f"✅ 成功导入人物FBX并绑定BVH动画到 {target_armature.name}! (FPS: {bpy.context.scene.render.fps})"
                    self.report({'INFO'}, msg)
                    print(f"===== 模板绑定完成:{msg} =====")
                else:
                    # 失败时保留导入的人物，方便用户检查；只提示错误
                    self.report({'ERROR'}, "动画转移到人物FBX模板失败!")
                    return {'CANCELLED'}

            else:
                # 创建新骨骼模式
                msg = f"✅ 成功生成Mixamo骨骼! (FPS: {bpy.context.scene.render.fps})"
                self.report({'INFO'}, msg)
                print(f"===== 生成完成:{msg} =====")
            
        except Exception as e:
            import traceback
            error_msg = f"处理失败:{str(e)}"
            self.report({'ERROR'}, error_msg)
            print(f"===== 转化失败:{error_msg} =====")
            print(traceback.format_exc())
            return {'CANCELLED'}
        
        return {'FINISHED'}

# -------------------------- 文件选择类 --------------------------
class FILE_OT_select_bvh(Operator):
    bl_idname = "file.select_bvh"
    bl_label = "选择BVH文件"
    bl_description = "选择动捕导出的BVH文件"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.bvh", options={'HIDDEN'})

    def execute(self, context):
        context.scene.bvh_input_path = self.filepath
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class FILE_OT_select_mapping_json(Operator):
    bl_idname = "file.select_mapping_json"
    bl_label = "选择骨骼映射JSON"
    bl_description = "选择自定义BVH到Mixamo骨骼映射JSON文件"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        context.scene.bvh_custom_mapping_path = self.filepath
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class FILE_OT_select_template_fbx(Operator):
    bl_idname = "file.select_template_fbx"
    bl_label = "选择人物FBX模板"
    bl_description = "选择自定义Mixamo人物FBX模板文件"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.fbx", options={'HIDDEN'})

    def execute(self, context):
        context.scene.bvh_custom_template_fbx_path = self.filepath
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

# -------------------------- 插件面板 --------------------------
class MIXAMO_PT_panel(Panel):
    bl_idname = "MIXAMO_PT_main_panel"
    bl_label = "BVH → Mixamo 转化工具"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mixamo Tools'
    bl_context = "objectmode"

    def draw_header(self, context):
        layout = self.layout
        logo_preview = load_logo()
        if logo_preview and 'plugin_logo' in logo_preview:
            layout.label(icon_value=logo_preview['plugin_logo'].icon_id)
        else:
            layout.label(icon='ARMATURE_DATA')

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.1

        # 1. BVH文件选择
        box = layout.box()
        box.label(text="选择BVH动捕文件", icon='IMPORT')
        row = box.row(align=True)
        row.prop(context.scene, "bvh_input_path", text="")
        row.operator("file.select_bvh", text="", icon='FILEBROWSER')
        
        # 2. 帧率设置
        box.prop(context.scene, "bvh_match_fps", text="自动匹配BVH帧率")
        layout.separator()
        
        # 3. v3.0:骨骼映射配置
        box = layout.box()
        box.label(text="骨骼映射配置", icon='BONE_DATA')
        box.prop(context.scene, "bvh_mapping_preset", text="映射来源")
        if context.scene.bvh_mapping_preset == MAPPING_PRESET_DEFAULT:
            default_path = get_default_mapping_json_path()
            box.label(text="使用内置 default_mixamo_mapping.json", icon='CHECKMARK')
            if not os.path.exists(default_path):
                row = box.row()
                row.alert = True
                row.label(text="内置JSON缺失，将回退到代码默认映射", icon='ERROR')
        else:
            row = box.row(align=True)
            row.prop(context.scene, "bvh_custom_mapping_path", text="")
            row.operator("file.select_mapping_json", text="", icon='FILEBROWSER')
            if not context.scene.bvh_custom_mapping_path:
                row = box.row()
                row.alert = True
                row.label(text="请选择自定义JSON映射文件", icon='ERROR')
        layout.separator()
        
        # 4. 输出模式选择
        box = layout.box()
        box.label(text="输出模式", icon='MODIFIER')
        box.prop(context.scene, "bvh_bind_mode", text="")

        # 显示当前选中的Mixamo骨骼
        if context.scene.bvh_bind_mode in {'BIND', 'BIND_SELECTED'}:
            selected_mixamo = get_selected_mixamo_armature()
            if selected_mixamo:
                row = box.row()
                row.label(text=f"目标: {selected_mixamo.name}", icon='CHECKMARK')
            else:
                row = box.row()
                row.alert = True
                row.label(text="⚠ 请先选中Mixamo骨骼!", icon='ERROR')

        # v3.1: 人物FBX模板绑定配置
        if context.scene.bvh_bind_mode == 'BIND_TEMPLATE':
            sub = box.box()
            sub.label(text="人物FBX模板", icon='OUTLINER_OB_ARMATURE')
            sub.prop(context.scene, "bvh_template_preset", text="模板来源")

            if context.scene.bvh_template_preset == TEMPLATE_PRESET_BUILTIN_DEFAULT:
                template_path = get_default_template_fbx_path()
                sub.label(text="使用内置 Mixamo默认人物模型.fbx", icon='CHECKMARK')
                if not os.path.exists(template_path):
                    row = sub.row()
                    row.alert = True
                    row.label(text="内置人物FBX缺失", icon='ERROR')
            else:
                row = sub.row(align=True)
                row.prop(context.scene, "bvh_custom_template_fbx_path", text="")
                row.operator("file.select_template_fbx", text="", icon='FILEBROWSER')
                if not context.scene.bvh_custom_template_fbx_path:
                    row = sub.row()
                    row.alert = True
                    row.label(text="请选择自定义Mixamo人物FBX", icon='ERROR')

        layout.separator()

        # 5. 执行按钮
        row = layout.row()
        row.scale_y = 2.0

        # 根据模式显示不同按钮文本
        if context.scene.bvh_bind_mode in {'BIND', 'BIND_SELECTED'}:
            btn_text = "绑定到选中骨骼"
            btn_icon = 'LINKED'
        elif context.scene.bvh_bind_mode == 'BIND_TEMPLATE':
            btn_text = "绑定到人物FBX模板"
            btn_icon = 'OUTLINER_OB_ARMATURE'
        else:
            btn_text = "生成新Mixamo骨骼"
            btn_icon = 'ARMATURE_DATA'

        row.operator("mixamo.convert_bvh", text=btn_text, icon=btn_icon)
        layout.separator()

        # 6. 说明信息
        box = layout.box()
        box.label(text="💡 使用说明", icon='INFO')
        col = box.column(align=True)
        col.scale_y = 0.85
        col.label(text="v3.1.0 新功能:")
        col.label(text="  • 支持内置JSON骨骼映射")
        col.label(text="  • 支持自定义JSON映射切换")
        col.label(text="  • 支持内置人物FBX模板绑定")
        col.label(text="  • 保留原创建/绑定功能")
        col.separator(factor=0.5)
        col.label(text="输出模式:")
        col.label(text="  • 创建新骨骼: 生成独立骨骼")
        col.label(text="  • 绑定选中骨骼: 转移动画到现有角色")
        col.label(text="  • 绑定人物模板: 导入FBX并生成动画角色")
        col.separator(factor=0.5)
        col.label(text="使用流程:")
        col.label(text="  1. 选择BVH文件")
        col.label(text="  2. 选择骨骼映射来源")
        col.label(text="  3. 选择输出模式")
        col.label(text="  4. 模板模式会自动导入FBX人物")
        col.label(text="  5. 选中骨骼模式需先选中角色")
        col.label(text="  6. 点击按钮执行")
        col.separator(factor=0.5)
        col.label(text="注意事项:")
        col.label(text="  • 选中骨骼模式需选中Mixamo格式骨骼")
        col.label(text="  • 自定义JSON建议包含mapping字段")
        col.label(text="  • 建议勾选'自动匹配BVH帧率'")
        col.label(text="  • 绑定后原BVH骨骼会自动删除")

# -------------------------- 插件注册/注销 --------------------------
classes = (
    MIXAMO_OT_convert,
    FILE_OT_select_bvh,
    FILE_OT_select_mapping_json,
    FILE_OT_select_template_fbx,
    MIXAMO_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.bvh_input_path = StringProperty(
        name="BVH输入路径",
        default="",
        description="选择BVH动捕文件路径"
    )
    
    bpy.types.Scene.bvh_match_fps = BoolProperty(
        name="匹配BVH帧率",
        default=True,
        description="自动读取BVH文件的帧率并设置到场景(推荐开启)"
    )
    
    # 新增:绑定模式选项
    bpy.types.Scene.bvh_bind_mode = EnumProperty(
        name="输出模式",
        description="选择如何处理转换后的动画",
        items=[
            ('CREATE', "创建新骨骼", "生成新的Mixamo格式骨骼到场景中", 'ARMATURE_DATA', 0),
            ('BIND_SELECTED', "绑定到选中骨骼", "将动画绑定到场景中选中的Mixamo骨骼上", 'LINKED', 1),
            ('BIND_TEMPLATE', "绑定到人物FBX模板", "导入内置或自定义Mixamo人物FBX，并将BVH动画绑定到该人物上", 'OUTLINER_OB_ARMATURE', 2),
        ],
        default='CREATE'
    )

    bpy.types.Scene.bvh_mapping_preset = EnumProperty(
        name="骨骼映射来源",
        description="选择BVH源骨骼到Mixamo目标骨骼的映射配置",
        items=[
            (MAPPING_PRESET_DEFAULT, "内置默认JSON", "使用插件自带presets/default_mixamo_mapping.json", 'PRESET', 0),
            (MAPPING_PRESET_CUSTOM, "自定义JSON", "使用用户选择的自定义骨骼映射JSON", 'FILE', 1),
        ],
        default=MAPPING_PRESET_DEFAULT
    )

    bpy.types.Scene.bvh_custom_mapping_path = StringProperty(
        name="自定义JSON映射路径",
        default="",
        description="选择自定义BVH到Mixamo骨骼映射JSON文件",
        subtype='FILE_PATH'
    )

    bpy.types.Scene.bvh_template_preset = EnumProperty(
        name="人物FBX模板来源",
        description="选择用于一键绑定的人物FBX模板",
        items=[
            (TEMPLATE_PRESET_BUILTIN_DEFAULT, "内置默认人物", "使用插件自带templates/mixamo_default_character.fbx", 'PRESET', 0),
            (TEMPLATE_PRESET_CUSTOM_FBX, "自定义FBX", "使用用户选择的Mixamo人物FBX模板", 'FILE', 1),
        ],
        default=TEMPLATE_PRESET_BUILTIN_DEFAULT
    )

    bpy.types.Scene.bvh_custom_template_fbx_path = StringProperty(
        name="自定义人物FBX路径",
        default="",
        description="选择自定义Mixamo人物FBX模板文件",
        subtype='FILE_PATH'
    )
    
    load_logo()
    print("✅ BVH to Mixamo Converter v3.1.0 已注册")

def unregister():
    unload_logo()
    
    del bpy.types.Scene.bvh_input_path
    del bpy.types.Scene.bvh_match_fps
    del bpy.types.Scene.bvh_bind_mode
    del bpy.types.Scene.bvh_mapping_preset
    del bpy.types.Scene.bvh_custom_mapping_path
    del bpy.types.Scene.bvh_template_preset
    del bpy.types.Scene.bvh_custom_template_fbx_path
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    print("✅ BVH to Mixamo Converter v3.1.0 已注销")

if __name__ == "__main__":
    register()