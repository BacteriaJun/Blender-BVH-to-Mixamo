# 插件作者：Junius
# 版本：2.3.1 - 修复帧率同步问题

bl_info = {
    "name": "BVH to Mixamo Converter",
    "author": "Junius",
    "version": (2, 3, 1),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > Mixamo Tools",
    "description": "一键将BVH骨骼转化为Mixamo标准骨骼(修复帧率同步)",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

import bpy
import os
import re
from mathutils import Vector
from bpy.props import StringProperty, BoolProperty
from bpy.types import Operator, Panel

# -------------------------- Logo预留配置 --------------------------
LOGO_PATH = "icons/logo.png"
LOGO_ICON_ID = None

# -------------------------- 核心：Mixamo标准骨骼映射 --------------------------
BONE_MAPPING = {
    # 躯干核心骨骼
    "Hips": "mixamorig:Hips",
    "Spine": "mixamorig:Spine",
    "Spine1": "mixamorig:Spine1",
    "Spine2": "mixamorig:Spine2",
    "Neck": "mixamorig:Neck",
    "Head": "mixamorig:Head",

    # 左臂骨骼
    "LeftShoulder": "mixamorig:LeftShoulder",
    "LeftArm": "mixamorig:LeftArm",
    "LeftForeArm": "mixamorig:LeftForeArm",
    "LeftHand": "mixamorig:LeftHand",
    "LeftHandThumb1": "mixamorig:LeftHandThumb1",
    "LeftHandThumb2": "mixamorig:LeftHandThumb2",
    "LeftHandThumb3": "mixamorig:LeftHandThumb3",
    "LeftHandIndex1": "mixamorig:LeftHandIndex1",
    "LeftHandIndex2": "mixamorig:LeftHandIndex2",
    "LeftHandIndex3": "mixamorig:LeftHandIndex3",
    "LeftHandMiddle1": "mixamorig:LeftHandMiddle1",
    "LeftHandMiddle2": "mixamorig:LeftHandMiddle2",
    "LeftHandMiddle3": "mixamorig:LeftHandMiddle3",
    "LeftHandRing1": "mixamorig:LeftHandRing1",
    "LeftHandRing2": "mixamorig:LeftHandRing2",
    "LeftHandRing3": "mixamorig:LeftHandRing3",
    "LeftHandPinky1": "mixamorig:LeftHandPinky1",
    "LeftHandPinky2": "mixamorig:LeftHandPinky2",
    "LeftHandPinky3": "mixamorig:LeftHandPinky3",

    # 右臂骨骼
    "RightShoulder": "mixamorig:RightShoulder",
    "RightArm": "mixamorig:RightArm",
    "RightForeArm": "mixamorig:RightForeArm",
    "RightHand": "mixamorig:RightHand",
    "RightHandThumb1": "mixamorig:RightHandThumb1",
    "RightHandThumb2": "mixamorig:RightHandThumb2",
    "RightHandThumb3": "mixamorig:RightHandThumb3",
    "RightHandIndex1": "mixamorig:RightHandIndex1",
    "RightHandIndex2": "mixamorig:RightHandIndex2",
    "RightHandIndex3": "mixamorig:RightHandIndex3",
    "RightHandMiddle1": "mixamorig:RightHandMiddle1",
    "RightHandMiddle2": "mixamorig:RightHandMiddle2",
    "RightHandMiddle3": "mixamorig:RightHandMiddle3",
    "RightHandRing1": "mixamorig:RightHandRing1",
    "RightHandRing2": "mixamorig:RightHandRing2",
    "RightHandRing3": "mixamorig:RightHandRing3",
    "RightHandPinky1": "mixamorig:RightHandPinky1",
    "RightHandPinky2": "mixamorig:RightHandPinky2",
    "RightHandPinky3": "mixamorig:RightHandPinky3",

    # 左腿骨骼
    "LeftUpLeg": "mixamorig:LeftUpLeg",
    "LeftLeg": "mixamorig:LeftLeg",
    "LeftFoot": "mixamorig:LeftFoot",
    "LeftToeBase": "mixamorig:LeftToeBase",

    # 右腿骨骼
    "RightUpLeg": "mixamorig:RightUpLeg",
    "RightLeg": "mixamorig:RightLeg",
    "RightFoot": "mixamorig:RightFoot",
    "RightToeBase": "mixamorig:RightToeBase",
}

# -------------------------- Mixamo标准骨骼层级 --------------------------
MIXAMO_BONE_HIERARCHY = {
    "mixamorig:Hips": ["mixamorig:Spine", "mixamorig:LeftUpLeg", "mixamorig:RightUpLeg"],
    "mixamorig:Spine": ["mixamorig:Spine1"],
    "mixamorig:Spine1": ["mixamorig:Spine2"],
    "mixamorig:Spine2": ["mixamorig:Neck", "mixamorig:LeftShoulder", "mixamorig:RightShoulder"],
    "mixamorig:Neck": ["mixamorig:Head"],

    # 左臂层级
    "mixamorig:LeftShoulder": ["mixamorig:LeftArm"],
    "mixamorig:LeftArm": ["mixamorig:LeftForeArm"],
    "mixamorig:LeftForeArm": ["mixamorig:LeftHand"],
    "mixamorig:LeftHand": [
        "mixamorig:LeftHandThumb1", "mixamorig:LeftHandIndex1", 
        "mixamorig:LeftHandMiddle1", "mixamorig:LeftHandRing1", "mixamorig:LeftHandPinky1"
    ],
    "mixamorig:LeftHandThumb1": ["mixamorig:LeftHandThumb2"],
    "mixamorig:LeftHandThumb2": ["mixamorig:LeftHandThumb3"],
    "mixamorig:LeftHandIndex1": ["mixamorig:LeftHandIndex2"],
    "mixamorig:LeftHandIndex2": ["mixamorig:LeftHandIndex3"],
    "mixamorig:LeftHandMiddle1": ["mixamorig:LeftHandMiddle2"],
    "mixamorig:LeftHandMiddle2": ["mixamorig:LeftHandMiddle3"],
    "mixamorig:LeftHandRing1": ["mixamorig:LeftHandRing2"],
    "mixamorig:LeftHandRing2": ["mixamorig:LeftHandRing3"],
    "mixamorig:LeftHandPinky1": ["mixamorig:LeftHandPinky2"],
    "mixamorig:LeftHandPinky2": ["mixamorig:LeftHandPinky3"],

    # 右臂层级
    "mixamorig:RightShoulder": ["mixamorig:RightArm"],
    "mixamorig:RightArm": ["mixamorig:RightForeArm"],
    "mixamorig:RightForeArm": ["mixamorig:RightHand"],
    "mixamorig:RightHand": [
        "mixamorig:RightHandThumb1", "mixamorig:RightHandIndex1", 
        "mixamorig:RightHandMiddle1", "mixamorig:RightHandRing1", "mixamorig:RightHandPinky1"
    ],
    "mixamorig:RightHandThumb1": ["mixamorig:RightHandThumb2"],
    "mixamorig:RightHandThumb2": ["mixamorig:RightHandThumb3"],
    "mixamorig:RightHandIndex1": ["mixamorig:RightHandIndex2"],
    "mixamorig:RightHandIndex2": ["mixamorig:RightHandIndex3"],
    "mixamorig:RightHandMiddle1": ["mixamorig:RightHandMiddle2"],
    "mixamorig:RightHandMiddle2": ["mixamorig:RightHandMiddle3"],
    "mixamorig:RightHandRing1": ["mixamorig:RightHandRing2"],
    "mixamorig:RightHandRing2": ["mixamorig:RightHandRing3"],
    "mixamorig:RightHandPinky1": ["mixamorig:RightHandPinky2"],
    "mixamorig:RightHandPinky2": ["mixamorig:RightHandPinky3"],

    # 左腿层级
    "mixamorig:LeftUpLeg": ["mixamorig:LeftLeg"],
    "mixamorig:LeftLeg": ["mixamorig:LeftFoot"],
    "mixamorig:LeftFoot": ["mixamorig:LeftToeBase"],

    # 右腿层级
    "mixamorig:RightUpLeg": ["mixamorig:RightLeg"],
    "mixamorig:RightLeg": ["mixamorig:RightFoot"],
    "mixamorig:RightFoot": ["mixamorig:RightToeBase"],
}

# -------------------------- Logo加载工具 --------------------------
def load_logo():
    global LOGO_ICON_ID
    if LOGO_ICON_ID is not None:
        return LOGO_ICON_ID
    addon_path = os.path.dirname(os.path.abspath(__file__))
    logo_abs_path = os.path.join(addon_path, LOGO_PATH)
    if os.path.exists(logo_abs_path):
        try:
            preview_collection = bpy.utils.previews.new()
            preview_collection.load('plugin_logo', logo_abs_path, 'IMAGE')
            LOGO_ICON_ID = preview_collection
            print(f"✅ 加载Logo成功:{logo_abs_path}")
        except Exception as e:
            print(f"⚠️ Logo加载失败:{str(e)}")
            LOGO_ICON_ID = None
    else:
        print(f"⚠️ Logo文件不存在:{logo_abs_path}(使用默认图标)")
        LOGO_ICON_ID = None
    return LOGO_ICON_ID

def unload_logo():
    global LOGO_ICON_ID
    if LOGO_ICON_ID is not None:
        bpy.utils.previews.remove(LOGO_ICON_ID)
        LOGO_ICON_ID = None
    print("✅ Logo资源已卸载")

# -------------------------- 新增：读取BVH帧率 --------------------------
def read_bvh_framerate(bvh_path):
    """从BVH文件读取帧率"""
    try:
        with open(bvh_path, 'r') as f:
            for line in f:
                if 'Frame Time:' in line:
                    # 提取帧时间 (例如: "Frame Time: 0.033333")
                    match = re.search(r'Frame Time:\s*([\d.]+)', line)
                    if match:
                        frame_time = float(match.group(1))
                        fps = 1.0 / frame_time
                        print(f"📊 检测到BVH帧率: {fps:.2f} FPS (帧时间: {frame_time}s)")
                        return fps
    except Exception as e:
        print(f"⚠️ 读取BVH帧率失败: {e}")
    
    # 默认返回30fps (常见的动捕帧率)
    print("⚠️ 未检测到BVH帧率,使用默认值: 30 FPS")
    return 30.0

# -------------------------- 核心功能函数 --------------------------
def import_bvh(bvh_path, match_fps=True):
    """导入BVH文件并设置正确的帧率"""
    if not os.path.exists(bvh_path) or not bvh_path.lower().endswith(".bvh"):
        return None, None
    
    # 读取BVH原始帧率
    bvh_fps = read_bvh_framerate(bvh_path)
    
    # 如果启用帧率匹配,设置场景帧率
    if match_fps:
        bpy.context.scene.render.fps = int(round(bvh_fps))
        bpy.context.scene.render.fps_base = 1.0
        print(f"✅ 场景帧率已设置为: {bpy.context.scene.render.fps} FPS")
    
    # 导入BVH (关闭自动缩放,保持原始时间)
    bpy.ops.import_anim.bvh(
        filepath=bvh_path,
        axis_forward='-Z',
        axis_up='Y',
        target='ARMATURE',
        use_fps_scale=False,  # 关键修改:不自动缩放帧率
        update_scene_fps=match_fps,  # 根据选项更新场景帧率
        update_scene_duration=True,  # 更新场景时长
        use_cyclic=False,
        rotate_mode='NATIVE'
    )
    
    armature = bpy.context.selected_objects[0] if bpy.context.selected_objects else None
    return armature, bvh_fps

def process_bones(armature):
    """处理骨骼:映射名称+修复层级+修正位置"""
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='EDIT')
    
    edit_bones = armature.data.edit_bones
    
    # 1. 先保存原始骨骼位置信息(在重命名前)
    bone_positions = {}
    for old_name in BONE_MAPPING.keys():
        if old_name in edit_bones:
            bone = edit_bones[old_name]
            bone_positions[old_name] = {
                'head': bone.head.copy(),
                'tail': bone.tail.copy(),
                'roll': bone.roll,
                'matrix': bone.matrix.copy()
            }
    
    # 2. 清理多余骨骼
    bvh_bone_names = set(bone.name for bone in edit_bones)
    keep_bvh_names = set(BONE_MAPPING.keys())
    bones_to_delete = [name for name in bvh_bone_names if name not in keep_bvh_names]
    
    extra_end_bones = ["HeadTop_End", "LeftToeEnd", "RightToeEnd"]
    for end_bone in extra_end_bones:
        if end_bone in edit_bones and end_bone not in bones_to_delete:
            bones_to_delete.append(end_bone)
    
    for bone_name in bones_to_delete:
        if bone_name in edit_bones:
            edit_bones.remove(edit_bones[bone_name])
    print(f"✅ 清理多余骨骼:共删除 {len(bones_to_delete)} 个")
    
    # 3. 映射骨骼名称
    mapped_count = 0
    for old_name, new_name in BONE_MAPPING.items():
        if old_name in edit_bones:
            edit_bones[old_name].name = new_name
            mapped_count += 1
    print(f"✅ 骨骼名称映射:成功映射 {mapped_count} 个核心骨骼")
    
    # 4. 修复骨骼层级(设置父子关系,但保持原始位置)
    for parent_name, child_names in MIXAMO_BONE_HIERARCHY.items():
        if parent_name in edit_bones:
            parent_bone = edit_bones[parent_name]
            for child_name in child_names:
                if child_name in edit_bones:
                    child_bone = edit_bones[child_name]
                    # 保存子骨骼的原始位置
                    original_head = child_bone.head.copy()
                    original_tail = child_bone.tail.copy()
                    original_roll = child_bone.roll
                    
                    # 设置父子关系
                    child_bone.parent = parent_bone
                    
                    # 恢复原始位置(不强制连接到父骨骼尾部)
                    child_bone.head = original_head
                    child_bone.tail = original_tail
                    child_bone.roll = original_roll
                    
                    # 确保骨骼有合理长度
                    if child_bone.length < 0.001:
                        direction = (child_bone.tail - child_bone.head).normalized()
                        child_bone.tail = child_bone.head + direction * 0.01
    
    print(f"✅ 骨骼层级修复完成(保持原始位置)")
    
    # 5. 特别处理:确保左右腿从Hips正确分叉
    if "mixamorig:Hips" in edit_bones:
        hips = edit_bones["mixamorig:Hips"]
        
        # 左腿应该从Hips的左侧位置开始
        if "mixamorig:LeftUpLeg" in edit_bones:
            left_leg = edit_bones["mixamorig:LeftUpLeg"]
            left_leg.parent = hips
            left_leg.use_connect = False
        
        # 右腿应该从Hips的右侧位置开始
        if "mixamorig:RightUpLeg" in edit_bones:
            right_leg = edit_bones["mixamorig:RightUpLeg"]
            right_leg.parent = hips
            right_leg.use_connect = False
    
    # 6. 确保所有子骨骼都不使用连接(use_connect=False)
    for bone in edit_bones:
        if bone.parent:
            bone.use_connect = False
    
    print(f"✅ 骨骼位置优化完成(腿部分叉正确)")
    
    # 7. 切换到物体模式
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = armature
    armature.select_set(True)
    
    return armature

def verify_animation_data(armature):
    """验证动画数据是否正确"""
    if not armature.animation_data or not armature.animation_data.action:
        print("⚠️ 警告:骨架没有动画数据!")
        return False
    
    action = armature.animation_data.action
    fcurves = action.fcurves
    
    if len(fcurves) == 0:
        print("⚠️ 警告:动画没有关键帧曲线!")
        return False
    
    # 统计关键帧信息
    total_keyframes = sum(len(fc.keyframe_points) for fc in fcurves)
    frame_range = action.frame_range
    
    print(f"✅ 动画数据验证:")
    print(f"  - 动画名称: {action.name}")
    print(f"  - 曲线数量: {len(fcurves)}")
    print(f"  - 总关键帧: {total_keyframes}")
    print(f"  - 帧范围: {frame_range[0]:.0f} - {frame_range[1]:.0f}")
    
    return True

# -------------------------- 操作类 --------------------------
class MIXAMO_OT_convert(Operator):
    bl_idname = "mixamo.convert_bvh"
    bl_label = "生成骨骼到场景"
    bl_description = "将BVH骨骼转换为Mixamo标准骨骼并添加到当前场景"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bvh_path = context.scene.bvh_input_path
        match_fps = context.scene.bvh_match_fps
        
        if not bvh_path:
            self.report({'ERROR'}, "请选择BVH输入文件!")
            return {'CANCELLED'}
        
        if not bvh_path.lower().endswith(".bvh"):
            self.report({'ERROR'}, "请选择有效的BVH文件(.bvh后缀)!")
            return {'CANCELLED'}
        
        try:
            print("===== 开始BVH→Mixamo转化 =====")
            
            # 导入BVH并设置帧率
            armature, bvh_fps = import_bvh(bvh_path, match_fps)
            if not armature:
                self.report({'ERROR'}, "BVH导入失败!请检查文件路径和格式。")
                return {'CANCELLED'}
            
            # 验证动画数据
            if not verify_animation_data(armature):
                self.report({'WARNING'}, "动画数据可能不完整,请检查!")
            
            # 处理骨骼
            processed_armature = process_bones(armature)
            
            # 最终验证
            verify_animation_data(processed_armature)
            
            msg = f"✅ 成功生成Mixamo骨骼! (FPS: {bpy.context.scene.render.fps})"
            self.report({'INFO'}, msg)
            print(f"===== 生成完成:{msg} =====")
            
        except Exception as e:
            import traceback
            error_msg = f"处理失败:{str(e)}"
            self.report({'ERROR'}, error_msg)
            print(f"===== 转化失败:{error_msg} =====")
            print(traceback.format_exc())
            return {'CANCELLED'}
        
        return {'FINISHED'}

# -------------------------- 文件选择类 --------------------------
class FILE_OT_select_bvh(Operator):
    bl_idname = "file.select_bvh"
    bl_label = "选择BVH文件"
    bl_description = "选择动捕导出的BVH文件"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.bvh", options={'HIDDEN'})

    def execute(self, context):
        context.scene.bvh_input_path = self.filepath
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

# -------------------------- 插件面板 --------------------------
class MIXAMO_PT_panel(Panel):
    bl_idname = "MIXAMO_PT_main_panel"
    bl_label = "BVH → Mixamo 转化工具"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mixamo Tools'
    bl_context = "objectmode"

    def draw_header(self, context):
        layout = self.layout
        logo_preview = load_logo()
        if logo_preview and 'plugin_logo' in logo_preview:
            layout.label(icon_value=logo_preview['plugin_logo'].icon_id)
        else:
            layout.label(icon='ARMATURE_DATA')

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.1

        # 1. BVH文件选择
        box = layout.box()
        box.label(text="选择BVH动捕文件", icon='IMPORT')
        row = box.row(align=True)
        row.prop(context.scene, "bvh_input_path", text="")
        row.operator("file.select_bvh", text="", icon='FILEBROWSER')
        
        # 2. 帧率设置选项
        box.prop(context.scene, "bvh_match_fps", text="自动匹配BVH帧率")
        layout.separator()

        # 3. 执行按钮
        row = layout.row()
        row.scale_y = 2.0
        row.operator("mixamo.convert_bvh", text="生成Mixamo骨骼", icon='ARMATURE_DATA')
        layout.separator()

        # 4. 说明信息
        box = layout.box()
        box.label(text="💡 使用说明", icon='INFO')
        col = box.column(align=True)
        col.scale_y = 0.85
        col.label(text="新功能:")
        col.label(text="  • 自动匹配BVH原始帧率")
        col.label(text="  • 修复动画速度不一致问题")
        col.label(text="  • 验证动画数据完整性")
        col.separator(factor=0.5)
        col.label(text="功能:")
        col.label(text="  • 转换BVH为Mixamo标准骨骼")
        col.label(text="  • 保持原始动画和骨骼大小")
        col.label(text="  • 修正腿部分叉问题")
        col.label(text="  • 兼容ARP/Rigify重映射")
        col.separator(factor=0.5)
        col.label(text="注意事项:")
        col.label(text="  • 文件路径使用英文(无中文/空格)")
        col.label(text="  • 建议勾选'自动匹配BVH帧率'")
        col.label(text="  • 可在编辑模式下进一步调整")

# -------------------------- 插件注册/注销 --------------------------
classes = (
    MIXAMO_OT_convert,
    FILE_OT_select_bvh,
    MIXAMO_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.bvh_input_path = StringProperty(
        name="BVH输入路径",
        default="",
        description="选择BVH动捕文件路径"
    )
    
    bpy.types.Scene.bvh_match_fps = BoolProperty(
        name="匹配BVH帧率",
        default=True,
        description="自动读取BVH文件的帧率并设置到场景(推荐开启)"
    )
    
    load_logo()
    print("✅ BVH to Mixamo Converter v2.3.1 已注册")

def unregister():
    unload_logo()
    
    del bpy.types.Scene.bvh_input_path
    del bpy.types.Scene.bvh_match_fps
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    print("✅ BVH to Mixamo Converter v2.3.1 已注销")

if __name__ == "__main__":
    register()